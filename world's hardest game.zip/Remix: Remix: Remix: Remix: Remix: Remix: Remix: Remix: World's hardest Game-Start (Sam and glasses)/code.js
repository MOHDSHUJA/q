var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["c36c4dd0-3529-43b1-868b-201533b01815","39b5eb9e-8057-4300-a166-6aee565edf8e","6f10f339-23e8-4453-bc95-9fcea4041080","f761baaa-1fe4-421b-855f-49b9c08a8f90","3525e21d-c690-4f54-a071-1e42132f4f2a","49a4462f-b78d-4b94-b503-91ed2360d69e","aa84b33a-eb42-4e8a-8620-51e013b4ec9c","6cef5f2c-a78a-4762-af91-30f683ff44f0","aeba5503-90ee-445f-b158-5fa16f922d44","6989d44a-0fb2-4ec7-a945-57d368557433","3cd4b1eb-4c37-4cf2-9e0c-5816c0eb7f32","ab356264-d506-4453-ada1-c6e21abc1b1a"],"propsByKey":{"c36c4dd0-3529-43b1-868b-201533b01815":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"5Cdf1i96ru8M_IK1vdGmxE58obXgo.Ry","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/c36c4dd0-3529-43b1-868b-201533b01815.png"},"39b5eb9e-8057-4300-a166-6aee565edf8e":{"name":"car1.velocityY=8;   car2.velocityY=5;   car3.velocityY=6;   car4.velocityY=8;","sourceUrl":"assets/api/v1/animation-library/gamelab/3gafkWdeEnlb1buwKOYL.MeGDmRw3vDK/category_vehicles/monstertruck_02.png","frameSize":{"x":394,"y":232},"frameCount":1,"looping":true,"frameDelay":2,"version":"3gafkWdeEnlb1buwKOYL.MeGDmRw3vDK","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":232},"rootRelativePath":"assets/api/v1/animation-library/gamelab/3gafkWdeEnlb1buwKOYL.MeGDmRw3vDK/category_vehicles/monstertruck_02.png"},"6f10f339-23e8-4453-bc95-9fcea4041080":{"name":"car1.velocityY=8;   car2.velocityY=5;   car3.velocityY=6;   car4.velocityY=8;_copy_1","sourceUrl":"assets/api/v1/animation-library/gamelab/3gafkWdeEnlb1buwKOYL.MeGDmRw3vDK/category_vehicles/monstertruck_02.png","frameSize":{"x":394,"y":232},"frameCount":1,"looping":true,"frameDelay":2,"version":"3gafkWdeEnlb1buwKOYL.MeGDmRw3vDK","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":232},"rootRelativePath":"assets/api/v1/animation-library/gamelab/3gafkWdeEnlb1buwKOYL.MeGDmRw3vDK/category_vehicles/monstertruck_02.png"},"f761baaa-1fe4-421b-855f-49b9c08a8f90":{"name":"car_black_1","sourceUrl":null,"frameSize":{"x":5,"y":9},"frameCount":3,"looping":true,"frameDelay":12,"version":"B0ErvjVyhO1dsJkjN3c56Rc..CtLbBKD","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":10,"y":18},"rootRelativePath":"assets/f761baaa-1fe4-421b-855f-49b9c08a8f90.png"},"3525e21d-c690-4f54-a071-1e42132f4f2a":{"name":"car_black_1_copy_1","sourceUrl":null,"frameSize":{"x":3,"y":6},"frameCount":2,"looping":false,"frameDelay":12,"version":"aQ44s.GHiP7lQ3V_62PXH4wlld.x3CKu","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":6,"y":6},"rootRelativePath":"assets/3525e21d-c690-4f54-a071-1e42132f4f2a.png"},"49a4462f-b78d-4b94-b503-91ed2360d69e":{"name":"car_black_2","sourceUrl":null,"frameSize":{"x":10,"y":18},"frameCount":1,"looping":true,"frameDelay":12,"version":"66FsXBcL5ePlIcVPGpz6xCOJhIFvRymI","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":10,"y":18},"rootRelativePath":"assets/49a4462f-b78d-4b94-b503-91ed2360d69e.png"},"aa84b33a-eb42-4e8a-8620-51e013b4ec9c":{"name":"car_green_1","sourceUrl":null,"frameSize":{"x":10,"y":18},"frameCount":1,"looping":true,"frameDelay":12,"version":"ZIHAudgHmS1WG.M73FM00CIe_QuarnDU","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":10,"y":18},"rootRelativePath":"assets/aa84b33a-eb42-4e8a-8620-51e013b4ec9c.png"},"6cef5f2c-a78a-4762-af91-30f683ff44f0":{"name":"car_red_1","sourceUrl":null,"frameSize":{"x":10,"y":18},"frameCount":1,"looping":true,"frameDelay":12,"version":"Vij819PrvakiiFzt9_jkrrEN73YiomLp","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":10,"y":18},"rootRelativePath":"assets/6cef5f2c-a78a-4762-af91-30f683ff44f0.png"},"aeba5503-90ee-445f-b158-5fa16f922d44":{"name":"car_yellow_1","sourceUrl":null,"frameSize":{"x":10,"y":18},"frameCount":1,"looping":true,"frameDelay":12,"version":"LtxpKABEkO2cZj9PdwPoyzrwOM1pgY8b","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":10,"y":18},"rootRelativePath":"assets/aeba5503-90ee-445f-b158-5fa16f922d44.png"},"6989d44a-0fb2-4ec7-a945-57d368557433":{"name":"car_green_2","sourceUrl":null,"frameSize":{"x":10,"y":18},"frameCount":1,"looping":true,"frameDelay":12,"version":"8pPTr_Y.RnTyCwGr_h0g7KZMToiXsNhu","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":10,"y":18},"rootRelativePath":"assets/6989d44a-0fb2-4ec7-a945-57d368557433.png"},"3cd4b1eb-4c37-4cf2-9e0c-5816c0eb7f32":{"name":"grey_shirt2_1","sourceUrl":null,"frameSize":{"x":10,"y":28},"frameCount":1,"looping":true,"frameDelay":12,"version":"LLkyrZ75zt_w243p9DDf9k8777EVcSuI","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":10,"y":28},"rootRelativePath":"assets/3cd4b1eb-4c37-4cf2-9e0c-5816c0eb7f32.png"},"ab356264-d506-4453-ada1-c6e21abc1b1a":{"name":"court_1","sourceUrl":"assets/api/v1/animation-library/gamelab/T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV/category_backgrounds/background_court.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV/category_backgrounds/background_court.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var car1, car2, car3,car4;
var boundary1, boundary2;
var sam;

  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);
  
  sam = createSprite(20,190,13,13);
  sam.shapeColor = "green";
  
  car1 = createSprite(100,130,10,10);
  car1.shapeColor = "red";
  car2 = createSprite(215,130,10,10);
  car2.shapeColor = "red";
  car3 = createSprite(165,250,10,10);
  car3.shapeColor = "red";
  car4 = createSprite(270,250,10,10);
car4.shapeColor = "red";
car1.setAnimation("car_black_2");
car2.setAnimation("car_green_2");
car3.setAnimation("car_red_1");
car4.setAnimation("car_yellow_1");
sam.setAnimation("grey_shirt2_1");
  
  


var gameState="serve";
function draw() {
   background("white");
  text("Lives: " + life,200,100);
  strokeWeight(0);
  fill("lightblue");
  rect(0,120,52,140);
  fill("yellow");
  rect(345,120,52,140);
 
   if (gameState=="serve") {
      //display text
  textSize(18);
  fill("maroon");
  text("Press space to start",120,200);
      if (keyDown("space")) {
        car1.velocityY=8;
  car2.velocityY=5;
  car3.velocityY=6;
  car4.velocityY=8;
  gameState="play";
  
      }
  
  
   }
   if (gameState=="play") {
     
    
     
     gameState="end";
   }
   if (gameState=="end") {
    
  
   }
   
   
 
  
// create bounceoff function to make the car bounceoff the boundaries
   createEdgeSprites();
car1.bounceOff(boundary1)
   car1.bounceOff(boundary2);
   car2.bounceOff(boundary1);
   car2.bounceOff(boundary2);
   car3.bounceOff(boundary1);
   car3.bounceOff(boundary2);
   car4.bounceOff(boundary1);
   car4.bounceOff(boundary2);
//Add the condition to make the sam move left and right
   if (keyDown("right")) {
     sam.x = sam.x+2;
   }
   if (keyDown("left")) {
     sam = sam.x-2;
   }

//Add the condition to reduce the life of sam if it touches the car.
  
   if( sam.isTouching(car1)|| sam.isTouching(car2)|| sam.isTouching(car3)|| sam.isTouching(car4))
   { sam.x = 20; sam.y = 190; life = life + 1; }  
  
   if (life==5) {
     fill("maroon");
     textSize(18);
     text("Game Over!", 170, 200);
     sam.x = 50;
     sam.y = 200;
     sam.velocityX = 0;
     sam.velocityY = 0;
     car1.x = 200;
     car1.y = 200;
     car1.velocityX = 0;
     car1.velocityY = 0;
     car2.x = 200;
     car2.y = 200;
     car2.velocityX = 0;
     car2.velocityY = 0;
     car3.x = 200;
     car3.y = 200;
     car3.velocityX = 0;
     car3.velocityY = 0;
     car4.x = 200;
     car4.y = 200;
     car4.velocityX = 0;
     car4.velocityY = 0;
   }

  
 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
